package MVC.CONTROLLER.RoomController;

import MVC.VIEW.GUIManager.*;
import MVC.HRS.Room.*;
//import MVC.VIEW.GUIManager.*;

import java.util.*;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class RoomController
{
    
    
    
    public RoomController()
    {
        
       
       
    }
    
    
    public Room[] roomCheck(int number,int day,int month,int year,int outDay,int outMonth,int outYear) 
    {
        Date enter = new Date(year,month,day);
        Date out = new Date(outYear,outMonth,outDay);
        
        Room[] rooms = new Room[1];
        rooms[0] = new Room(number);
        
        rooms = GUIManager.hotel.findFreeRoom(enter, out,rooms);
        
            return rooms;
    }
    
    public String showReservations() 
    {
        
        return GUIManager.hotel.toString();
    }
    
}