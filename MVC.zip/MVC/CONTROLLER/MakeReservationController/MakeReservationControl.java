package MVC.CONTROLLER.MakeReservationController;

import MVC.VIEW.GUIManager.*;
import MVC.HRS.User.*;
import MVC.HRS.Room.*;
import MVC.HRS.Reservation.*;

import java.util.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MakeReservationControl 
{
    
    
   
    
    
    public MakeReservationControl()
    {
        
        
    }
    
    
    public String booking(Date enter,Date out,Customer c, int number, Room[] rooms) 
    {
       Reservation r = GUIManager.hotel.createReservation( enter, out, rooms );
       
       
        r = GUIManager.hotel.makeBooking( c.getName(), c.getLastName(), c.getId(),c.getPhoneNumber(),r);
        return r.getCode();
        
    }
    
    public String cancelBooking(String code) 
    {
       
        boolean re = GUIManager.hotel.removeReservation(GUIManager.hotel.findReservation(code));
        
        if(re)
            return "Your reservation with reservation number " + code + " is removed.";
        else
            return "Fail";
    }
    
    
}