package MVC.VIEW.InfoManagerPanel;

import MVC.CONTROLLER.RoomController.*;

import javax.swing.JFrame;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.util.*;
import javax.swing.SwingConstants;
    
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class �nfoManagerPanel extends JPanel 
{
    
    JLabel label;
    
    RoomController check;
    
    
    
    public �nfoManagerPanel()
    {
        super();
        
        check = new RoomController();
        
        label = new JLabel();
        label.setText(check.showReservations());
        //label.setBounds(20, 20, 150, 20);
        //label.setVerticalAlignment(SwingConstants.CENTER);
        
        add(label);
        
    }
 
}