package MVC.VIEW.MainPanel;

import MVC.VIEW.InfoCustomerPanel.*;
import MVC.VIEW.InfoManagerPanel.*;
import MVC.VIEW.MakeReservationPanel.*;
import MVC.VIEW.GUIManager.*;
import MVC.CONTROLLER.MakeReservationController.*;

import java.util.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MainPanel extends JPanel implements ActionListener
{
    
    JButton button;
    JButton button2;
    JButton buttonM;
    
    JTextField rescode;
    String input;
    
    JTextField password;
   
    �nfoCustomerPanel �nfoCustomer ;
    �nfoManagerPanel �nfoManager ;
    
    MakeReservationControl cancelRes ;
    
    public MainPanel()
    {
        
        button = new JButton("customer");
        button.addActionListener(this);
        add(button);
        
        buttonM = new JButton("sign in as a manager");
        buttonM.addActionListener(this);
        //add(buttonM);
        
        password = new JTextField(6);
        //add(password);
        
        button2 = new JButton("cancel reservation with code");
        button2.addActionListener(this);
        add(button2);
        
        rescode = new JTextField(8);
        add(rescode);
       
    }
    
    
    public void actionPerformed(ActionEvent e) 
    {
       
        if( e.getActionCommand().equals("customer") )
        {
            setVisible(false);
            �nfoCustomer = new �nfoCustomerPanel();
            �nfoCustomer.setBounds(0, 100, 400, 600);
            GUIManager.frame.add(�nfoCustomer);
            �nfoCustomer.requestFocus(true);
            �nfoCustomer.requestFocusInWindow();
            GUIManager.frame.repaint();
        }
        
        if( e.getActionCommand().equals("cancel reservation with code") )
        {
            cancelRes= new MakeReservationControl();
            input = cancelRes.cancelBooking(rescode.getText());
            JOptionPane.showMessageDialog(this,input);
        }
        
        if( e.getActionCommand().equals("sign in as a manager") )
        {
            if( password.getText().equals("manage") )
            {
            setVisible(false);
            �nfoManager = new �nfoManagerPanel();
            �nfoManager.setBounds(0, 100, 400, 600);
            GUIManager.frame.add(�nfoManager);
            �nfoManager.requestFocus(true);
            �nfoManager.requestFocusInWindow();
            GUIManager.frame.repaint();
            }
            else{
                JOptionPane.showMessageDialog(this,"Wrong Password");
            }
        }
        
    }
    
}