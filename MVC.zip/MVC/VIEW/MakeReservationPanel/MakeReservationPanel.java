package MVC.VIEW.MakeReservationPanel;

import MVC.VIEW.MainPanel.*;
import MVC.VIEW.GUIManager.*;
import MVC.CONTROLLER.MakeReservationController.*;
import MVC.HRS.User.*;
import MVC.HRS.Room.*;

import java.util.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MakeReservationPanel extends JPanel implements ActionListener
{
    Date entDate;
    Date outDate;
    String nme;
    String srname;
    long �D;
    Room[] i;
    int number;
    MainPanel newMain;
    
    private static int count;
    
    String c;
    
    String code;
    
    int price;
    
    String showPrice;
    
    JButton button;
    JButton button2;
   
    MakeReservationControl makeRes ;
    
    public MakeReservationPanel(Date enter,Date out,String name,String surname,long �d,int nmber,Room[] rooms)
    {
        entDate=enter;
        outDate=out;
        nme=name;
        srname=surname;
        �D=�d;
        number=nmber;
        i=rooms;
        
        button = new JButton("make reservation");
        button.addActionListener(this);
        add(button);
        
        button2 = new JButton("back main");
        button2.addActionListener(this);
        add(button2);
        
        
       
    }
    
    
    public void actionPerformed(ActionEvent e) 
    {
       
        if( e.getActionCommand().equals("make reservation") )
        {
            if( number==1 )
                price=120;
            if( number==2 )
                price=150;
            if( number==3 )
                price=200;
            if( number==4 )
                price=250;
            if( number==5 )
                price=300;
            showPrice=" Amount you need to pay: " + price;
            count++;
            c=""+count;
            Customer c= new Customer(nme,srname,�D);
            makeRes= new MakeReservationControl();
            code = makeRes.booking(entDate,outDate,c,number,i);
            showPrice= showPrice + "  and your reservation code: "+ code; 
            System.out.println(code);
            JOptionPane.showMessageDialog(this,showPrice);
            /*setVisible(false);
            showResCode = new ShowResCodePanel();
            showResCode.setBounds(0, 100, 400, 600);
            FrameDeneme.frame.add(showResCode);
            showResCode.requestFocus(true);
            showResCode.requestFocusInWindow();
            FrameDeneme.frame.repaint();*/
        }
        
        if( e.getActionCommand().equals("back main") )
        {
            setVisible(false);
            newMain = new MainPanel();
            GUIManager.frame.add(newMain);
            GUIManager.frame.setVisible(true);
            GUIManager.frame.setBounds(200,200,400,300);
            
            GUIManager.frame.repaint();
        }
        
    }
    
}