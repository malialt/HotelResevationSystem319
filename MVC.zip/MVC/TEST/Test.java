package MVC.TEST;

import MVC.HRS.Hotel.*;
import MVC.HRS.Room.*;
import MVC.HRS.ReservationNode.*;
import MVC.HRS.Reservation.*;
import MVC.HRS.User.*;

import java.util.*;
public class Test
{
    public static void main( String[] args )
    {
      
        Hotel h = new Hotel(8 , 10 , 90 , 40);
        String[] s = {"TV", "Breakfast", "Mini-bar", "Beverage Maker", "Wifi"};
        int[] prices = {12, 14, 50, 50, 10};
        h.setFeatureNames(s);
        h.setFeaturePrices(prices);
        Room[][] rooms = h.getAllRooms();
        
        
        Room[] searchRoom = new Room[4];
        
        for( int i = 0; i<4; i++)
            searchRoom[i] = new Room(i+1);
        
        Date enter = new Date(2017, 6, 19);
        Date out = new Date(2017, 6, 23);
        
        Date enter2 = new Date(2017, 6, 9);
        Date out2 = new Date(2017, 6, 18);
        
        Room[] found1 = h.findFreeRoom(enter,out,searchRoom);
        Reservation r = h.createReservation(enter, out, found1);
        
        int[] fe = {1,0,1,1,0};
        r = h.selectRoomFeatures(r, found1[2], fe);
        r = h.makeBooking("irem","yurdakul",15456985696L, 905343649040L, r );
        
        System.out.println("First Reservation \n\n\n" );
        System.out.println( r.showDetails() );
        ////////////////////////////////////////////////////////////////
        Room[] found2 = h.findFreeRoom( enter , out , searchRoom);
        Reservation r2 = h.createReservation(enter, out, found2);
        
        int[] fer = {1,1,1,0,0};
        r2 = h.selectRoomFeatures(r2, found2[1], fer);
        r2 = h.makeBooking("mehmet","ali",14792187476L, 90061542500L, r2 );
        
        System.out.println("Second Reservation \n\n\n" );
        System.out.println( r2.showDetails() );
        
        ///////////////////////////////////////////////////////////////////
        Room[] found3 = h.findFreeRoom(enter2,out2,searchRoom);
        Reservation r3 = h.createReservation(enter2, out2, found3);
        
        int[] fe5 = {0,1,1,1,1};
        r3 = h.selectRoomFeatures(r3, found3[3], fe5);
        r3 = h.makeBooking("bok","g�t",15456985696L, 905343649040L, r3 );
        
        System.out.println("First Reservation \n\n\n" );
        System.out.println( r3.showDetails() );
        /////////////////////////////////////////////////////////////////////
        String code = r2.getCode();
        
        Reservation rF = h.findReservation(code);
        
        System.out.println("Found Reservation \n\n\n" + " Reservation Code : " + code + "\n\n\n");
        System.out.println( rF.showDetails() );
        ////////////////////////////////////////////////////////////////////
        System.out.println("\n\n\n");
        System.out.println( h.removeReservation(rF) + "\n\n\n");
        
        //////////////////////////////////////////////////////////////////////
        rF = h.findReservation(code);
        
        if( !h.reservationExists(rF) )
            System.out.println( h.noExistingReservationWarning());
        else
            System.out.println( rF.showDetails() );
        
        
        
        Reservation[] rArray = h.getRoomReservations( rooms[0][0]);
        System.out.println(h.showRoomDetails(rooms[0][0]));
        for( int i = 0; i<rArray.length; i++)
        {
            System.out.println( h.showReservationDetails(rArray[i]));
        }
        
        //////////////////////////////////////////////
        /*System.out.println("W�th a Customer" );
          System.out.println( r.showDetails() );
        
          
          System.out.println("W�th Selections" );
          System.out.println( r.showDetails() );
          
          
          Room[][] roomie = h.getAllRooms();
                    System.out.println("First Room" );
          ReservationNode res = roomie[1][0].getReservations();
           System.out.println( res.item.showDetails() );
              System.out.println("Second Room" );
            res = roomie[2][1].getReservations();
           System.out.println( res.item.showDetails() );
               System.out.println("Third Room" );
            res = roomie[3][2].getReservations();
           System.out.println( res.item.showDetails() );
               System.out.println("Fourth Room" );
            res = roomie[4][3].getReservations();
           System.out.println( res.item.showDetails() );
           System.out.println("Fifth Room" );
            res = roomie[5][4].getReservations();
           System.out.println( res.item.showDetails() );
           
           System.out.println("Sixth Room" );
            res = roomie[6][5].getReservations();
            if( res.item == null)
                System.out.println("No reservations" );
            else{
                System.out.println( res.item.showDetails() );}
          */
          
        /*long a1 = 24565878998L;
        long a2 = 16766764698L;
        Customer c1 = new Customer("Murat","S�erdem",a1);
         Customer c2 = new Customer("Mehmet Ali","Altunta�",a2);
         Customer c3 = new Customer("irem","yurdakul",15456985696L);
         Customer c4 = new Customer("eda","b��ak��",85698585696L);

       h.findFreeRoom(1,19,6,2017,23,6,2017,c1);
       h.findFreeRoom(1,24,6,2017,28,6,2017,c2);
       h.findFreeRoom(1,28,6,2017,29,6,2017,c3);
       h.findFreeRoom(1,25,6,2017,29,6,2017,c3);
       h.findFreeRoom(1,25,6,2017,29,6,2017,c4);
       System.out.println( h.showReservation("101MA1698"));
       System.out.println( h.showReservation("101MS2498"));
       System.out.println( h.showReservation("101MS2498"));
       System.out.println( h.showReservation("102IY1596"));
       System.out.println( h.showReservation("303MS2498"));
       System.out.println( h.showReservation("001MS2498"));
       System.out.println( h.showReservation("100MS2498"));
       System.out.println( h.showReservation("601MS2498"));
       System.out.println( h.showReservation("507MS2498"));
       System.out.println( h.showReservation("507MS2498"));
       
       System.out.println(h);*/
    }
}